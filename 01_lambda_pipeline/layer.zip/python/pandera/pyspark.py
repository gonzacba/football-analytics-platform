"""A flexible and expressive pyspark validation library."""

from pandera._patch_numpy2 import _patch_numpy2

_patch_numpy2()

import pandera.backends.base.builtin_checks
import pandera.backends.base.builtin_hypotheses
import pandera.backends.pyspark
from pandera import errors, external_config
from pandera._version import __version__
from pandera.accessors import pyspark_sql_accessor
from pandera.api.checks import Check
from pandera.api.dataframe.model_components import check, dataframe_check
from pandera.api.pyspark import Column, DataFrameSchema
from pandera.api.pyspark.model import DataFrameModel
from pandera.api.pyspark.model_components import Field
from pandera.decorators import check_input, check_io, check_output, check_types
from pandera.dtypes import (
    Bool,
    Category,
    Complex,
    Complex64,
    Complex128,
    Complex256,
    DataType,
    Date,
    DateTime,
    Decimal,
    Float,
    Float16,
    Float32,
    Float64,
    Float128,
    Int,
    Int8,
    Int16,
    Int32,
    Int64,
    String,
    Timedelta,
    Timestamp,
    UInt,
    UInt8,
    UInt16,
    UInt32,
    UInt64,
)
from pandera.errors import PysparkSchemaError, SchemaInitError
from pandera.schema_inference.pyspark import (
    infer_dataframe_schema,
    infer_schema,
)
from pandera.typing import pyspark_sql
from pandera.typing import pyspark_sql as typing

external_config._set_pyspark_environment_variables()

__all__ = [
    # dtypes
    "Bool",
    "Category",
    "Complex",
    "Complex64",
    "Complex128",
    "Complex256",
    "DataType",
    "DateTime",
    "Float",
    "Float16",
    "Float32",
    "Float64",
    "Float128",
    "Int",
    "Int8",
    "Int16",
    "Int32",
    "Int64",
    "String",
    "Timedelta",
    "Timestamp",
    "UInt",
    "UInt8",
    "UInt16",
    "UInt32",
    "UInt64",
    # checks
    "Check",
    # decorators
    "check_input",
    "check_io",
    "check_output",
    "check_types",
    # model
    "DataFrameModel",
    # model_components
    "Field",
    "check",
    "dataframe_check",
    # schema_components
    "Column",
    # schema_inference
    "infer_dataframe_schema",
    "infer_schema",
    # schemas
    "DataFrameSchema",
    # version
    "__version__",
]
